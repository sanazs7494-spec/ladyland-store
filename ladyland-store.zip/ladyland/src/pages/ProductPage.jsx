import { useState, useEffect } from 'react'
import { useApp } from '../store/context'
import { CATS, PALETTE_COLORS, SHIP_OPTS } from '../constants'
import { salePrice, money } from '../services/helpers'
import ProductCard from '../components/ProductCard'

function QtyControl({ value, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--border)' }}>
      <button onClick={() => onChange(value - 1)}
        style={{ width: 44, height: 52, fontSize: 20, color: 'var(--gray)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
      <span style={{ width: 44, textAlign: 'center', fontSize: 15 }}>{value}</span>
      <button onClick={() => onChange(value + 1)}
        style={{ width: 44, height: 52, fontSize: 20, color: 'var(--gray)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
    </div>
  )
}

export default function ProductPage() {
  const { s, d } = useApp()

  // Always read the live version from store (in case admin edited it)
  const liveP = s.products.find(x => x.id === s.currentProd?.id) ?? s.currentProd

  const [selImg,   setSelImg]   = useState(0)
  const [selColor, setSelColor] = useState('')
  const [selSize,  setSelSize]  = useState('')
  const [qty,      setQty]      = useState(1)

  useEffect(() => {
    if (!liveP) return
    setSelImg(0)
    setSelColor(liveP.colors?.[0] || '')
    setSelSize(liveP.sizes?.[0]  || '—')
    setQty(1)
  }, [liveP?.id])

  if (!liveP) return null

  const fp      = salePrice(liveP)
  const invKey  = liveP.sizes?.length ? `${selSize}-${selColor}` : selColor
  const stock   = (liveP.inventory || {})[invKey] ?? 99
  const inWish  = s.wish.some(x => x.id === liveP.id)
  const catName = CATS.find(c => c.id === liveP.category)?.fa || ''
  const similar = s.products
    .filter(x => x.category === liveP.category && x.id !== liveP.id)
    .slice(0, 4)

  const addToCart = () => {
    d({
      type: 'CART_ADD',
      pid:       liveP.id,
      name:      liveP.name,
      unitPrice: fp,
      color:     selColor,
      size:      selSize,
      qty,
      thumb:     liveP.images?.[0] || null,
    })
  }

  return (
    <div className="anim-fadeIn" style={{ maxWidth: 1200, margin: '0 auto', padding: '48px 32px' }}>

      {/* Breadcrumb */}
      <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 36, display: 'flex', gap: 10, alignItems: 'center' }}>
        <button onClick={() => d({ type: 'PAGE', p: 'shop' })} style={{ color: 'var(--muted)', transition: 'color .2s' }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--ink)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--muted)'}>فروشگاه</button>
        <span style={{ opacity: .4 }}>›</span>
        <button onClick={() => { d({ type: 'FCAT', v: liveP.category }); d({ type: 'PAGE', p: 'shop' }) }}
          style={{ color: 'var(--muted)', transition: 'color .2s' }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--ink)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--muted)'}>{catName}</button>
        <span style={{ opacity: .4 }}>›</span>
        <span style={{ color: 'var(--ink)' }}>{liveP.name}</span>
      </div>

      {/* Main grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 72, marginBottom: 96 }}>

        {/* ── Gallery ── */}
        <div>
          <div style={{ aspectRatio: '4/5', background: 'var(--cream)', overflow: 'hidden', marginBottom: 12, position: 'relative' }}>
            {liveP.images?.[selImg] ? (
              <img
                key={selImg}
                src={liveP.images[selImg]}
                alt={liveP.name}
                style={{ width: '100%', height: '100%', objectFit: 'cover', animation: 'fadeIn .3s ease' }}
              />
            ) : (
              <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12 }}>
                <span style={{ fontSize: 72, opacity: .1 }}>
                  {liveP.category === 'bags' ? '◉' : liveP.category === 'shoes' ? '◆' : liveP.category === 'acc' ? '◇' : '◈'}
                </span>
                <span style={{ fontSize: 11, color: 'var(--muted)', letterSpacing: 2 }}>NO IMAGE</span>
              </div>
            )}
          </div>

          {liveP.images?.length > 1 && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8 }}>
              {liveP.images.map((img, i) => (
                <button key={i} onClick={() => setSelImg(i)}
                  style={{ aspectRatio: '1', overflow: 'hidden', border: `2px solid ${selImg === i ? 'var(--gold)' : 'var(--border)'}`, transition: 'border .2s' }}>
                  <img src={img} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Details ── */}
        <div>
          <p style={{ fontSize: 9, letterSpacing: 4, color: 'var(--gold)', marginBottom: 10, fontWeight: 600 }}>
            LADY LAND — {CATS.find(c => c.id === liveP.category)?.en?.toUpperCase()}
          </p>
          <h1 className="serif" style={{ fontSize: 36, fontWeight: 400, lineHeight: 1.15, marginBottom: 4 }}>{liveP.name}</h1>
          <p style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 4, fontWeight: 300 }}>{liveP.nameEn}</p>
          <p style={{ fontSize: 11, color: 'var(--muted)', marginBottom: 28, letterSpacing: .3 }}>کد: {liveP.code}</p>

          {/* Price */}
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 16, marginBottom: 28, paddingBottom: 28, borderBottom: '1px solid var(--border)' }}>
            <span className="serif" style={{ fontSize: 30, fontWeight: 500 }}>{money(fp)}</span>
            {liveP.discount > 0 && (
              <>
                <span style={{ fontSize: 14, color: 'var(--muted)', textDecoration: 'line-through' }}>{money(liveP.price)}</span>
                <span style={{ background: 'var(--red)', color: '#fff', padding: '3px 9px', fontSize: 11 }}>−{liveP.discount}٪</span>
              </>
            )}
          </div>

          {/* Colors */}
          {liveP.colors?.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <p style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 12 }}>
                رنگ: <strong style={{ color: 'var(--ink)' }}>{selColor}</strong>
              </p>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {liveP.colors.map(c => (
                  <button key={c} title={c} onClick={() => setSelColor(c)}
                    style={{
                      width: 32, height: 32, borderRadius: '50%',
                      background: PALETTE_COLORS[c] || '#ccc',
                      border: `3px solid ${selColor === c ? 'var(--gold)' : 'var(--border)'}`,
                      boxShadow: selColor === c ? '0 0 0 2px var(--gold)' : 'none',
                      transition: 'all .2s',
                    }} />
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          {liveP.sizes?.length > 0 && (
            <div style={{ marginBottom: 28 }}>
              <p style={{ fontSize: 11, color: 'var(--gray)', marginBottom: 12 }}>سایز:</p>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {liveP.sizes.map(sz => {
                  const sk = `${sz}-${selColor}`
                  const st = (liveP.inventory || {})[sk] ?? 0
                  return (
                    <button key={sz} disabled={st === 0} onClick={() => st > 0 && setSelSize(sz)}
                      style={{
                        minWidth: 48, height: 48, padding: '0 12px',
                        border: `1.5px solid ${selSize === sz ? 'var(--gold)' : 'var(--border)'}`,
                        background: selSize === sz ? 'var(--gold)' : 'transparent',
                        color: selSize === sz ? '#fff' : st === 0 ? 'var(--muted)' : 'var(--ink)',
                        fontSize: 12, fontWeight: selSize === sz ? 600 : 400,
                        opacity: st === 0 ? .45 : 1,
                        cursor: st === 0 ? 'not-allowed' : 'pointer',
                        transition: 'all .2s',
                      }}>
                      {sz}
                    </button>
                  )
                })}
              </div>
              {stock > 0 && stock < 6 && (
                <p style={{ fontSize: 11, color: 'var(--red)', marginTop: 8 }}>فقط {stock} عدد موجود</p>
              )}
            </div>
          )}

          {/* Qty + CTA */}
          <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
            <QtyControl value={qty} onChange={setQty} />
            <button
              className={`btn ${stock > 0 ? 'btn-ink' : 'btn-ghost'}`}
              style={{ flex: 1, height: 52, fontSize: 12 }}
              disabled={stock <= 0}
              onClick={addToCart}
            >
              {stock > 0 ? 'افزودن به سبد خرید' : 'ناموجود'}
            </button>
            <button
              onClick={() => d({ type: 'WISH_TOGGLE', p: liveP })}
              style={{
                width: 52, height: 52,
                border: '1.5px solid var(--border)',
                fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'border .2s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--gold)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
            >{inWish ? '🩷' : '♡'}</button>
          </div>

          {/* Meta */}
          {(liveP.material || liveP.description) && (
            <div style={{ background: 'var(--cream)', padding: 20, fontSize: 13, lineHeight: 1.8, marginTop: 24 }}>
              {liveP.material && <p><strong>جنس:</strong> {liveP.material}</p>}
              {liveP.description && (
                <p style={{ color: 'var(--gray)', marginTop: liveP.material ? 8 : 0 }}>{liveP.description}</p>
              )}
            </div>
          )}

          {/* Trust badges */}
          <div style={{ display: 'flex', gap: 20, marginTop: 20, flexWrap: 'wrap' }}>
            {[['🚚', 'ارسال سریع'], ['↩️', '۷ روز مرجوعی'], ['✦', 'ضمانت اصالت']].map(([ic, t]) => (
              <div key={t} style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 11, color: 'var(--muted)' }}>
                {ic} {t}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Similar products */}
      {similar.length > 0 && (
        <>
          <div style={{ textAlign: 'center', marginBottom: 40 }}>
            <p style={{ fontSize: 9, letterSpacing: 5, color: 'var(--gold)', marginBottom: 10, fontWeight: 600 }}>YOU MAY ALSO LIKE</p>
            <h2 className="serif-i" style={{ fontSize: 30, fontWeight: 400 }}>محصولات مشابه</h2>
            <div className="gold-line" />
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(220px,1fr))', gap: 24 }}>
            {similar.map((p, i) => <ProductCard key={p.id} p={p} idx={i} />)}
          </div>
        </>
      )}
    </div>
  )
}
