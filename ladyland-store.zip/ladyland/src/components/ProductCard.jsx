import { useState } from 'react'
import { useApp } from '../store/context'
import { PALETTE_COLORS } from '../constants'
import { salePrice, money } from '../services/helpers'

export default function ProductCard({ p, idx = 0 }) {
  const { s, d } = useApp()
  const [hov, setHov]       = useState(false)
  const [imgIdx, setImgIdx] = useState(0)

  const inWish  = s.wish.some(w => w.id === p.id)
  const fp      = salePrice(p)
  const img     = p.images?.[hov && p.images.length > 1 ? 1 : imgIdx]
  const catIcon = { bags:'◉', shoes:'◆', acc:'◇' }[p.category] ?? '◈'

  return (
    <article
      className="card-lift anim-fadeUp"
      style={{ background: 'var(--white)', animationDelay: `${idx * .06}s`, position: 'relative', cursor: 'pointer' }}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      onClick={() => d({ type: 'OPEN_PROD', p })}
    >
      {/* ── Image area ── */}
      <div style={{ position: 'relative', aspectRatio: '2/3', overflow: 'hidden', background: 'var(--cream)' }}>
        {img ? (
          <img
            src={img} alt={p.name}
            style={{
              width: '100%', height: '100%', objectFit: 'cover',
              transition: 'transform .7s cubic-bezier(.16,1,.3,1)',
              transform: hov ? 'scale(1.07)' : 'scale(1)',
            }}
          />
        ) : (
          <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            <span style={{ fontSize: 52, opacity: .12 }}>{catIcon}</span>
            <span style={{ fontSize: 10, letterSpacing: 2, color: 'var(--muted)' }}>NO IMAGE</span>
          </div>
        )}

        {/* Badges */}
        <div style={{ position: 'absolute', top: 14, right: 14, display: 'flex', flexDirection: 'column', gap: 5 }}>
          {p.isNew      && <span className="tag tag-new">NEW</span>}
          {p.discount>0 && <span className="tag tag-sale">−{p.discount}٪</span>}
          {p.isBestseller && !p.isNew && <span className="tag tag-best">BESTSELLER</span>}
        </div>

        {/* Hover overlay */}
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(to top,rgba(14,14,12,.55) 0%,rgba(14,14,12,.0) 55%)',
          opacity: hov ? 1 : 0, transition: 'opacity .32s',
          display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', padding: 18,
        }}>
          <button
            className="btn btn-gold btn-sm" style={{ width: '100%' }}
            onClick={e => { e.stopPropagation(); d({ type: 'OPEN_PROD', p }) }}
          >مشاهده محصول</button>
        </div>

        {/* Wishlist button */}
        <button
          style={{
            position: 'absolute', top: 12, left: 12,
            width: 32, height: 32, borderRadius: '50%',
            background: 'rgba(255,255,255,.88)', backdropFilter: 'blur(6px)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 14, transition: 'all .22s',
            opacity: hov ? 1 : 0, transform: hov ? 'scale(1)' : 'scale(.8)',
          }}
          onClick={e => { e.stopPropagation(); d({ type: 'WISH_TOGGLE', p }) }}
        >{inWish ? '🩷' : '♡'}</button>

        {/* Image dots */}
        {p.images?.length > 1 && (
          <div style={{ position: 'absolute', bottom: 10, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 4, opacity: hov ? 1 : 0, transition: 'opacity .2s' }}>
            {p.images.map((_, i) => (
              <button
                key={i}
                onClick={e => { e.stopPropagation(); setImgIdx(i) }}
                style={{ width: i === imgIdx ? 20 : 6, height: 6, borderRadius: 3, background: i === imgIdx ? 'var(--gold)' : 'rgba(255,255,255,.7)', transition: 'all .2s' }}
              />
            ))}
          </div>
        )}
      </div>

      {/* ── Info ── */}
      <div style={{ padding: '16px 18px 20px' }}>
        <p style={{ fontSize: 9, letterSpacing: 3.5, color: 'var(--gold)', marginBottom: 7, fontWeight: 600 }}>LADY LAND</p>
        <h3 style={{ fontSize: 15, fontWeight: 400, marginBottom: 2, color: 'var(--ink)', lineHeight: 1.3 }}>{p.name}</h3>
        <p style={{ fontSize: 11, color: 'var(--muted)', marginBottom: 14, letterSpacing: .3 }}>{p.nameEn}</p>

        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 10 }}>
          <span className="serif" style={{ fontSize: 17, fontWeight: 500 }}>{money(fp)}</span>
          {p.discount > 0 && (
            <span style={{ fontSize: 12, color: 'var(--muted)', textDecoration: 'line-through' }}>{money(p.price)}</span>
          )}
        </div>

        {p.colors?.length > 0 && (
          <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
            {p.colors.slice(0, 6).map(c => (
              <div key={c} title={c} style={{ width: 11, height: 11, borderRadius: '50%', background: PALETTE_COLORS[c] || '#ccc', border: '1.5px solid var(--border)' }} />
            ))}
            {p.colors.length > 6 && <span style={{ fontSize: 10, color: 'var(--muted)' }}>+{p.colors.length - 6}</span>}
          </div>
        )}
      </div>
    </article>
  )
}
