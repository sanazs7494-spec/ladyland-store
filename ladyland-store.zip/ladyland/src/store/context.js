import { createContext, useContext } from 'react'

export const AppCtx = createContext(null)

/** @returns {{ s: import('./reducer').initState, d: (action: object) => void }} */
export const useApp = () => useContext(AppCtx)
