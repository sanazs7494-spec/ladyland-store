import { useRef, useState, useCallback } from 'react'
import { uploadImages } from '../services/database'

/**
 * ImageUploader — real file input, base64 preview, drag-drop, reorder
 * Ready for Supabase: swap uploadImages() in database.js to return URLs instead
 *
 * @param {{ images: string[], onChange: (imgs: string[]) => void }} props
 */
export default function ImageUploader({ images = [], onChange }) {
  const inputRef   = useRef()
  const [drag, setDrag]       = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')

  const MAX = 5

  const processFiles = useCallback(async (files) => {
    if (images.length >= MAX) {
      setError(`حداکثر ${MAX} تصویر مجاز است`)
      return
    }
    setLoading(true)
    setError('')
    try {
      const remaining  = MAX - images.length
      const sliced     = Array.from(files).slice(0, remaining)
      const newImgs    = await uploadImages(sliced)
      onChange([...images, ...newImgs])
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [images, onChange])

  const onDrop = useCallback(e => {
    e.preventDefault()
    setDrag(false)
    processFiles(e.dataTransfer.files)
  }, [processFiles])

  const remove = i => onChange(images.filter((_, j) => j !== i))

  const moveLeft = i => {
    if (i === 0) return
    const arr = [...images]
    ;[arr[i - 1], arr[i]] = [arr[i], arr[i - 1]]
    onChange(arr)
  }

  return (
    <div>
      {/* Drop zone */}
      <div
        onDrop={onDrop}
        onDragOver={e => { e.preventDefault(); setDrag(true) }}
        onDragLeave={() => setDrag(false)}
        onClick={() => !loading && inputRef.current.click()}
        style={{
          border: `2px dashed ${drag ? 'var(--gold)' : 'var(--border)'}`,
          padding: '28px 20px', textAlign: 'center',
          cursor: loading ? 'wait' : 'pointer',
          background: drag ? 'rgba(196,160,82,.05)' : 'var(--cream)',
          transition: 'all .22s', marginBottom: 14,
        }}
      >
        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 24, height: 24, border: '2px solid var(--gold)', borderTopColor: 'transparent', borderRadius: '50%', animation: 'spin 1s linear infinite' }} />
            <p style={{ fontSize: 12, color: 'var(--muted)' }}>در حال آپلود...</p>
          </div>
        ) : (
          <>
            <div style={{ fontSize: 28, marginBottom: 8, opacity: .35 }}>📷</div>
            <p style={{ fontSize: 13, color: 'var(--gray)', marginBottom: 3 }}>
              تصویر را اینجا رها کنید یا کلیک کنید
            </p>
            <p style={{ fontSize: 11, color: 'var(--muted)' }}>
              JPG · PNG · WEBP — حداکثر ۳.۵MB — تا {MAX} تصویر
            </p>
          </>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          multiple
          hidden
          onChange={e => processFiles(e.target.files)}
        />
      </div>

      {/* Error */}
      {error && (
        <p style={{ fontSize: 12, color: 'var(--red)', marginBottom: 10 }}>{error}</p>
      )}

      {/* Preview grid */}
      {images.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: `repeat(${MAX}, 1fr)`, gap: 8 }}>
          {images.map((src, i) => (
            <div key={i} style={{
              position: 'relative', aspectRatio: '1', overflow: 'hidden',
              border: `2px solid ${i === 0 ? 'var(--gold)' : 'var(--border)'}`,
            }}>
              <img src={src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              {i === 0 && (
                <span style={{
                  position: 'absolute', top: 3, right: 3,
                  background: 'var(--gold)', color: '#fff', fontSize: 8, padding: '1px 5px', letterSpacing: .5,
                }}>اصلی</span>
              )}
              <div style={{
                position: 'absolute', bottom: 0, left: 0, right: 0,
                background: 'rgba(0,0,0,.6)', display: 'flex', padding: '3px 5px', gap: 4,
              }}>
                {i > 0 && (
                  <button
                    onClick={() => moveLeft(i)}
                    title="جابجایی"
                    style={{ color: '#fff', fontSize: 13, lineHeight: 1, flex: 1 }}
                  >←</button>
                )}
                <button
                  onClick={() => remove(i)}
                  title="حذف"
                  style={{ color: '#fff', fontSize: 13, lineHeight: 1, flex: 1 }}
                >✕</button>
              </div>
            </div>
          ))}

          {/* Add more slot */}
          {images.length < MAX && (
            <button
              onClick={() => inputRef.current.click()}
              style={{
                aspectRatio: '1', border: '1.5px dashed var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--muted)', fontSize: 24, transition: 'all .2s',
              }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--gold)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
            >+</button>
          )}
        </div>
      )}
    </div>
  )
}
