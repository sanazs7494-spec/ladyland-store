import { useState } from 'react'
import { useApp } from '../store/context'
import { ORDER_STATUS } from '../constants'
import {
  addProduct, updateProduct, deleteProduct,
  updateOrderStatus, saveSettings,
} from '../services/database'
import ProductForm from '../components/ProductForm'
import { money } from '../services/helpers'

export default function AdminPage() {
  const { s, d } = useApp()
  const [showForm,    setShowForm]    = useState(false)
  const [editTarget,  setEditTarget]  = useState(null)
  const [prodSearch,  setProdSearch]  = useState('')

  // ── Product handlers ──────────────────────────────────────
  const handleSave = async (p) => {
    let next
    if (s.products.some(x => x.id === p.id)) {
      next = await updateProduct(p)
      d({ type: 'SET_PRODUCTS', list: next })
      d({ type: 'TOAST', payload: { msg: 'محصول ویرایش شد ✓', ok: true } })
    } else {
      next = await addProduct(p)
      d({ type: 'SET_PRODUCTS', list: next })
      d({ type: 'TOAST', payload: { msg: 'محصول جدید اضافه شد ✓', ok: true } })
    }
    setShowForm(false)
    setEditTarget(null)
  }

  const handleDelete = async (id) => {
    if (!window.confirm('این محصول حذف شود؟')) return
    const next = await deleteProduct(id)
    d({ type: 'SET_PRODUCTS', list: next })
    d({ type: 'TOAST', payload: { msg: 'محصول حذف شد', ok: true } })
  }

  const handleOrderStatus = async (id, status) => {
    const next = await updateOrderStatus(id, status)
    d({ type: 'SET_ORDERS', list: next })
  }

  const handleSaveSettings = async () => {
    await saveSettings(s.settings)
    d({ type: 'TOAST', payload: { msg: 'تنظیمات ذخیره شد ✓', ok: true } })
  }

  // ── Stats ─────────────────────────────────────────────────
  const totalRev  = s.orders.reduce((a, o) => a + o.total, 0)
  const statusCt  = k => s.orders.filter(o => o.status === k).length
  const TABS      = [['dash','داشبورد','▤'],['products','محصولات','◈'],['orders','سفارش‌ها','◉'],['settings','تنظیمات','◇']]

  // ── Filtered products for search in admin ─────────────────
  const filteredProds = prodSearch
    ? s.products.filter(p => p.name.includes(prodSearch) || (p.code || '').includes(prodSearch))
    : s.products

  return (
    <div style={{ display: 'flex', minHeight: '100vh' }}>

      {/* ── Sidebar ── */}
      <nav style={{ width: 210, background: 'var(--ink)', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
        <div style={{ padding: '26px 22px 22px', borderBottom: '1px solid rgba(255,255,255,.07)' }}>
          <div className="serif-i" style={{ color: '#fff', fontSize: 18 }}>Lady Land</div>
          <div style={{ fontSize: 8, color: 'var(--gold)', letterSpacing: 4, marginTop: 3 }}>ADMIN PANEL</div>
        </div>
        <div style={{ flex: 1, padding: '12px 0' }}>
          {TABS.map(([k, l, ic]) => (
            <button key={k} onClick={() => d({ type: 'ADMIN_TAB', tab: k })}
              style={{
                width: '100%', textAlign: 'right', padding: '12px 22px', fontSize: 12, letterSpacing: .3,
                display: 'flex', alignItems: 'center', gap: 10,
                color:      s.adminTab === k ? 'var(--gold-l)' : 'var(--muted)',
                background: s.adminTab === k ? 'rgba(196,160,82,.08)' : 'transparent',
                borderRight: `3px solid ${s.adminTab === k ? 'var(--gold)' : 'transparent'}`,
                transition: 'all .2s',
              }}>
              <span style={{ fontSize: 14 }}>{ic}</span>{l}
            </button>
          ))}
        </div>
        <div style={{ padding: '14px 22px', borderTop: '1px solid rgba(255,255,255,.07)' }}>
          <button onClick={() => d({ type: 'PAGE', p: 'shop' })}
            style={{ fontSize: 11, color: 'var(--muted)', letterSpacing: .5, transition: 'color .2s' }}
            onMouseEnter={e => e.currentTarget.style.color = '#fff'}
            onMouseLeave={e => e.currentTarget.style.color = 'var(--muted)'}>
            ← بازگشت به فروشگاه
          </button>
        </div>
      </nav>

      {/* ── Main ── */}
      <main style={{ flex: 1, background: '#F4F1EB', padding: 36, overflowY: 'auto' }}>

        {/* Dashboard */}
        {s.adminTab === 'dash' && (
          <div className="anim-fadeIn">
            <h2 className="serif-i" style={{ fontSize: 28, marginBottom: 32 }}>داشبورد</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: 18, marginBottom: 36 }}>
              {[['درآمد کل', money(totalRev), '💰'], ['سفارش‌ها', s.orders.length, '📦'], ['محصولات', s.products.length, '◈'], ['در انتظار', statusCt('new') + statusCt('process'), '⏳']].map(([l, v, ic]) => (
                <div key={l} style={{ background: '#fff', padding: 22, boxShadow: 'var(--shadow)' }}>
                  <div style={{ fontSize: 26, marginBottom: 10 }}>{ic}</div>
                  <div style={{ fontSize: 10, color: 'var(--muted)', letterSpacing: .5, marginBottom: 4 }}>{l}</div>
                  <div className="serif" style={{ fontSize: 22, fontWeight: 500 }}>{v}</div>
                </div>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
              <div style={{ background: '#fff', padding: 24, boxShadow: 'var(--shadow)' }}>
                <p style={{ fontWeight: 600, marginBottom: 18, fontSize: 14 }}>وضعیت سفارش‌ها</p>
                {Object.entries(ORDER_STATUS).map(([k, { fa, color }]) => (
                  <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13 }}>
                      <span style={{ width: 8, height: 8, borderRadius: '50%', background: color, display: 'inline-block' }} />
                      {fa}
                    </div>
                    <strong style={{ color, fontSize: 15 }}>{statusCt(k)}</strong>
                  </div>
                ))}
              </div>
              <div style={{ background: '#fff', padding: 24, boxShadow: 'var(--shadow)' }}>
                <p style={{ fontWeight: 600, marginBottom: 18, fontSize: 14 }}>آخرین سفارش‌ها</p>
                {s.orders.length === 0
                  ? <p style={{ color: 'var(--muted)', fontSize: 13 }}>هنوز سفارشی ثبت نشده</p>
                  : s.orders.slice(0, 5).map(o => (
                    <div key={o.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: '1px solid var(--border)', fontSize: 12 }}>
                      <span style={{ fontFamily: 'monospace', color: 'var(--muted)' }}>{o.id}</span>
                      <span style={{ fontWeight: 600 }}>{money(o.total)}</span>
                      <span style={{ color: ORDER_STATUS[o.status]?.color, fontSize: 11 }}>{ORDER_STATUS[o.status]?.fa}</span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        )}

        {/* Products */}
        {s.adminTab === 'products' && (
          <div className="anim-fadeIn">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
              <h2 className="serif-i" style={{ fontSize: 28 }}>محصولات</h2>
              <button className="btn btn-gold" onClick={() => { setShowForm(true); setEditTarget(null) }}>
                + محصول جدید
              </button>
            </div>

            {/* Admin search */}
            <div style={{ marginBottom: 20 }}>
              <input className="inp" placeholder="جستجو بر اساس نام یا کد..." value={prodSearch}
                onChange={e => setProdSearch(e.target.value)}
                style={{ maxWidth: 360 }} />
            </div>

            {(showForm || editTarget) && (
              <ProductForm
                product={editTarget}
                onSave={handleSave}
                onCancel={() => { setShowForm(false); setEditTarget(null) }}
              />
            )}

            {/* Table */}
            <div style={{ background: '#fff', boxShadow: 'var(--shadow)', overflowX: 'auto' }}>
              {filteredProds.length === 0 ? (
                <div style={{ textAlign: 'center', padding: 80, color: 'var(--muted)' }}>
                  <div style={{ fontSize: 48, marginBottom: 16, opacity: .15 }}>◈</div>
                  <p style={{ fontSize: 16, marginBottom: 6 }}>هیچ محصولی یافت نشد</p>
                  <p style={{ fontSize: 13 }}>روی «محصول جدید» کلیک کنید</p>
                </div>
              ) : (
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ background: 'var(--cream)' }}>
                      {['تصویر', 'نام', 'کد', 'قیمت', 'تخفیف', 'دسته', 'موجودی', 'عملیات'].map(h => (
                        <th key={h} style={{ padding: '11px 14px', textAlign: 'right', fontSize: 10, color: 'var(--muted)', fontWeight: 600, letterSpacing: .6, borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProds.map(p => {
                      const totalStock = Object.values(p.inventory || {}).reduce((a, b) => a + b, 0)
                      return (
                        <tr key={p.id} style={{ borderBottom: '1px solid var(--border)', transition: 'background .15s' }}
                          onMouseEnter={e => e.currentTarget.style.background = 'var(--ivory)'}
                          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                          <td style={{ padding: '12px 14px' }}>
                            <div style={{ width: 52, height: 64, background: 'var(--cream)', overflow: 'hidden' }}>
                              {p.images?.[0]
                                ? <img src={p.images[0]} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                                : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontSize: 18 }}>◈</div>}
                            </div>
                          </td>
                          <td style={{ padding: '12px 14px' }}>
                            <p style={{ fontSize: 13, fontWeight: 500, marginBottom: 2 }}>{p.name}</p>
                            <p style={{ fontSize: 11, color: 'var(--muted)' }}>{p.nameEn}</p>
                          </td>
                          <td style={{ padding: '12px 14px', fontSize: 11, color: 'var(--muted)', fontFamily: 'monospace' }}>{p.code}</td>
                          <td style={{ padding: '12px 14px', fontSize: 13, fontWeight: 600 }}>
                            {money(p.discount ? Math.round(p.price * (1 - p.discount / 100)) : p.price)}
                          </td>
                          <td style={{ padding: '12px 14px' }}>
                            {p.discount > 0
                              ? <span style={{ background: '#FFF0D0', color: '#8B6010', padding: '3px 8px', fontSize: 11, fontWeight: 600 }}>−{p.discount}٪</span>
                              : <span style={{ color: 'var(--muted)' }}>—</span>}
                          </td>
                          <td style={{ padding: '12px 14px', fontSize: 12, color: 'var(--gray)' }}>
                            {/* category label */}
                            {({ clothing: 'لباس', bags: 'کیف', shoes: 'کفش', acc: 'اکسسوری' })[p.category]}
                          </td>
                          <td style={{ padding: '12px 14px' }}>
                            <span style={{ fontSize: 14, fontWeight: 600, color: totalStock > 5 ? 'var(--green)' : totalStock > 0 ? '#B87A2A' : 'var(--red)' }}>
                              {totalStock}
                            </span>
                          </td>
                          <td style={{ padding: '12px 14px' }}>
                            <div style={{ display: 'flex', gap: 8 }}>
                              {[['ویرایش', 'var(--gold)', () => { setEditTarget(p); setShowForm(false) }],
                                ['حذف',   'var(--red)',  () => handleDelete(p.id)]].map(([label, color, fn]) => (
                                <button key={label} onClick={fn}
                                  style={{ fontSize: 11, border: `1px solid ${color}`, color, padding: '5px 11px', transition: 'all .2s' }}
                                  onMouseEnter={e => { e.currentTarget.style.background = color; e.currentTarget.style.color = '#fff' }}
                                  onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = color }}>
                                  {label}
                                </button>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        )}

        {/* Orders */}
        {s.adminTab === 'orders' && (
          <div className="anim-fadeIn">
            <h2 className="serif-i" style={{ fontSize: 28, marginBottom: 28 }}>سفارش‌ها</h2>
            {s.orders.length === 0 ? (
              <div style={{ textAlign: 'center', padding: 80, color: 'var(--muted)', background: '#fff' }}>
                <div style={{ fontSize: 44, marginBottom: 16, opacity: .15 }}>◉</div>
                <p style={{ fontSize: 16 }}>هنوز سفارشی ثبت نشده</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                {s.orders.map(o => (
                  <div key={o.id} style={{ background: '#fff', padding: 22, boxShadow: 'var(--shadow)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16, marginBottom: 12, flexWrap: 'wrap' }}>
                      <div>
                        <p style={{ fontFamily: 'monospace', fontWeight: 700, fontSize: 13, marginBottom: 3 }}>{o.id}</p>
                        <p style={{ fontSize: 11, color: 'var(--muted)' }}>{o.date} · {o.addr?.name} · {o.addr?.city}</p>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                        <span className="serif" style={{ fontSize: 18, fontWeight: 500 }}>{money(o.total)}</span>
                        <select value={o.status} onChange={e => handleOrderStatus(o.id, e.target.value)}
                          style={{ padding: '7px 12px', border: `1.5px solid ${ORDER_STATUS[o.status]?.color || 'var(--border)'}`, color: ORDER_STATUS[o.status]?.color || 'var(--ink)', fontSize: 12, background: '#fff', fontFamily: 'inherit', cursor: 'pointer' }}>
                          {Object.entries(ORDER_STATUS).map(([k, { fa }]) => <option key={k} value={k}>{fa}</option>)}
                        </select>
                      </div>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--gray)', borderTop: '1px solid var(--border)', paddingTop: 10 }}>
                      {o.items?.map(i => `${i.name} (${i.color}${i.size && i.size !== '—' ? ' / ' + i.size : ''}) ×${i.qty}`).join('  ·  ')}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Settings */}
        {s.adminTab === 'settings' && (
          <div className="anim-fadeIn">
            <h2 className="serif-i" style={{ fontSize: 28, marginBottom: 28 }}>تنظیمات فروشگاه</h2>
            <div style={{ background: '#fff', padding: 32, maxWidth: 580, boxShadow: 'var(--shadow)' }}>
              {[['heroTitle', 'عنوان اصلی (فارسی)', 'کالکشن بهار ۱۴۰۴'],
                ['heroEn',    'زیرعنوان (انگلیسی)',  'SPRING — SUMMER'],
                ['heroCopy',  'توضیح کوتاه',         '...'],
                ['ticker',    'نوار اطلاع‌رسانی',    'ارسال رایگان بالای ...']].map(([k, l, ph]) => (
                <div key={k} style={{ marginBottom: 18 }}>
                  <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 6, letterSpacing: .3 }}>{l}</label>
                  <input className="inp" value={s.settings[k] || ''} placeholder={ph}
                    onChange={e => d({ type: 'SET_SETTINGS', s: { ...s.settings, [k]: e.target.value } })} />
                </div>
              ))}
              <button className="btn btn-gold" onClick={handleSaveSettings}>ذخیره تنظیمات</button>
            </div>
          </div>
        )}

      </main>
    </div>
  )
}
