import { useApp } from '../store/context'
import { money } from '../services/helpers'
import { saveCartLocal } from '../services/database'
import { useEffect } from 'react'

function QtyControl({ value, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', border: '1px solid var(--border)' }}>
      <button onClick={() => onChange(value - 1)} style={{ width: 28, height: 28, fontSize: 16, color: 'var(--gray)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>−</button>
      <span style={{ width: 28, textAlign: 'center', fontSize: 13 }}>{value}</span>
      <button onClick={() => onChange(value + 1)} style={{ width: 28, height: 28, fontSize: 16, color: 'var(--gray)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
    </div>
  )
}

export default function CartDrawer() {
  const { s, d } = useApp()
  const total = s.cart.reduce((a, i) => a + i.unitPrice * i.qty, 0)

  // Persist cart on every change
  useEffect(() => { saveCartLocal(s.cart) }, [s.cart])

  if (!s.cartOpen) return null

  return (
    <>
      <div
        className="anim-fadeIn"
        style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,.38)', zIndex: 500 }}
        onClick={() => d({ type: 'TOGGLE_CART' })}
      />
      <aside
        className="anim-slideR"
        style={{ position: 'fixed', top: 0, left: 0, width: 'min(420px,100vw)', height: '100vh', background: 'var(--white)', zIndex: 600, display: 'flex', flexDirection: 'column', boxShadow: '-4px 0 48px rgba(0,0,0,.16)' }}
      >
        <div style={{ padding: '22px 24px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span className="serif-i" style={{ fontSize: 20 }}>سبد خرید ({s.cart.length})</span>
          <button onClick={() => d({ type: 'TOGGLE_CART' })} style={{ color: 'var(--muted)', fontSize: 22, lineHeight: 1 }}>✕</button>
        </div>

        <div style={{ flex: 1, overflowY: 'auto' }}>
          {s.cart.length === 0 ? (
            <div style={{ textAlign: 'center', paddingTop: 80, color: 'var(--muted)' }}>
              <div style={{ fontSize: 44, marginBottom: 16, opacity: .25 }}>◈</div>
              <p style={{ fontSize: 14 }}>سبد خرید خالی است</p>
            </div>
          ) : s.cart.map(item => (
            <div key={item.key} style={{ display: 'flex', gap: 14, padding: '16px 24px', borderBottom: '1px solid var(--border)' }}>
              <div style={{ width: 68, height: 84, background: 'var(--cream)', flexShrink: 0, overflow: 'hidden' }}>
                {item.thumb
                  ? <img src={item.thumb} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)', fontSize: 22 }}>◈</div>}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: 13, fontWeight: 500, marginBottom: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</p>
                <p style={{ fontSize: 11, color: 'var(--muted)', marginBottom: 10 }}>
                  {item.color}{item.size && item.size !== '—' ? ` — ${item.size}` : ''}
                </p>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <QtyControl value={item.qty} onChange={v => d({ type: 'CART_QTY', key: item.key, qty: v })} />
                  <span style={{ fontSize: 13, fontWeight: 600 }}>{money(item.unitPrice * item.qty)}</span>
                </div>
              </div>
              <button onClick={() => d({ type: 'CART_DEL', key: item.key })} style={{ alignSelf: 'flex-start', color: 'var(--muted)', fontSize: 18, padding: 4, lineHeight: 1 }}>✕</button>
            </div>
          ))}
        </div>

        {s.cart.length > 0 && (
          <div style={{ padding: '20px 24px', borderTop: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 18 }}>
              <span style={{ color: 'var(--gray)', fontSize: 13 }}>جمع کل</span>
              <span className="serif" style={{ fontSize: 20, fontWeight: 500 }}>{money(total)}</span>
            </div>
            <button
              className="btn btn-ink" style={{ width: '100%' }}
              onClick={() => { d({ type: 'TOGGLE_CART' }); d({ type: 'PAGE', p: 'checkout' }) }}
            >ادامه و پرداخت →</button>
          </div>
        )}
      </aside>
    </>
  )
}
