import { useState, useEffect } from 'react'
import { useApp } from '../store/context'
import { CATS } from '../constants'
import CartDrawer from './CartDrawer'

function Bubble({ n }) {
  return (
    <span style={{ position: 'absolute', top: -6, left: -6, background: 'var(--gold)', color: '#fff', fontSize: 9, width: 16, height: 16, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>
      {n > 9 ? '9+' : n}
    </span>
  )
}

export default function Header() {
  const { s, d } = useApp()
  const cartCount = s.cart.reduce((a, i) => a + i.qty, 0)
  const [stuck, setStuck] = useState(false)

  useEffect(() => {
    const fn = () => setStuck(window.scrollY > 50)
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])

  return (
    <>
      <header style={{
        position: 'sticky', top: 0, zIndex: 300,
        background: stuck ? 'rgba(250,250,247,.96)' : 'var(--ivory)',
        borderBottom: stuck ? '1px solid var(--border)' : '1px solid transparent',
        backdropFilter: stuck ? 'blur(14px)' : 'none',
        transition: 'all .3s',
      }}>
        <div style={{ maxWidth: 1320, margin: '0 auto', padding: '0 32px', height: 68, display: 'flex', alignItems: 'center', gap: 20 }}>

          {/* Logo */}
          <button onClick={() => d({ type: 'PAGE', p: 'shop' })} style={{ flexShrink: 0 }}>
            <div className="serif-i" style={{ fontSize: 22, letterSpacing: 1.5, color: 'var(--ink)', lineHeight: 1.1 }}>Lady Land</div>
            <div style={{ fontSize: 8, letterSpacing: 4, color: 'var(--gold)', marginTop: 2 }}>LUXURY FASHION</div>
          </button>

          {/* Nav */}
          <nav className="hide-sm" style={{ flex: 1, display: 'flex', justifyContent: 'center', gap: 8 }}>
            <button
              onClick={() => { d({ type: 'FCAT', v: null }); d({ type: 'PAGE', p: 'shop' }) }}
              style={{ padding: '6px 16px', fontSize: 12, letterSpacing: .5, color: !s.filterCat ? 'var(--ink)' : 'var(--gray)', borderBottom: `1.5px solid ${!s.filterCat ? 'var(--gold)' : 'transparent'}`, transition: 'all .2s' }}
            >همه</button>
            {CATS.map(c => (
              <button key={c.id}
                onClick={() => { d({ type: 'FCAT', v: c.id }); d({ type: 'PAGE', p: 'shop' }) }}
                style={{ padding: '6px 16px', fontSize: 12, letterSpacing: .5, color: s.filterCat === c.id ? 'var(--ink)' : 'var(--gray)', borderBottom: `1.5px solid ${s.filterCat === c.id ? 'var(--gold)' : 'transparent'}`, transition: 'all .2s' }}
              >{c.fa}</button>
            ))}
          </nav>

          {/* Icons */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 18, flexShrink: 0 }}>
            <button onClick={() => d({ type: 'TOGGLE_SRCH' })} style={{ display: 'flex', alignItems: 'center', color: 'var(--gray)', transition: 'color .2s' }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--ink)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--gray)'}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            </button>

            <button onClick={() => d({ type: 'PAGE', p: 'wish' })}
              style={{ position: 'relative', color: 'var(--gray)', transition: 'color .2s', display: 'flex' }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--ink)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--gray)'}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill={s.wish.length ? 'var(--gold)' : 'none'} stroke={s.wish.length ? 'var(--gold)' : 'currentColor'} strokeWidth="1.8"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
              {s.wish.length > 0 && <Bubble n={s.wish.length} />}
            </button>

            <button onClick={() => d({ type: 'TOGGLE_CART' })}
              style={{ position: 'relative', color: 'var(--gray)', transition: 'color .2s', display: 'flex' }}
              onMouseEnter={e => e.currentTarget.style.color = 'var(--ink)'}
              onMouseLeave={e => e.currentTarget.style.color = 'var(--gray)'}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
              {cartCount > 0 && <Bubble n={cartCount} />}
            </button>
          </div>
        </div>
      </header>

      {/* Search overlay */}
      {s.searchOpen && (
        <div className="anim-fadeIn"
          style={{ position: 'fixed', inset: 0, background: 'rgba(10,10,8,.93)', zIndex: 400, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => d({ type: 'TOGGLE_SRCH' })}>
          <div style={{ width: 'min(620px,90vw)' }} onClick={e => e.stopPropagation()}>
            <p style={{ fontSize: 10, letterSpacing: 5, color: 'var(--muted)', textAlign: 'center', marginBottom: 28 }}>SEARCH</p>
            <div style={{ display: 'flex', borderBottom: '2px solid var(--gold)', paddingBottom: 10 }}>
              <input autoFocus value={s.searchQ}
                onChange={e => { d({ type: 'SEARCH', q: e.target.value }); d({ type: 'PAGE', p: 'shop' }) }}
                onKeyDown={e => e.key === 'Escape' && d({ type: 'TOGGLE_SRCH' })}
                placeholder="جستجو در محصولات..."
                style={{ flex: 1, background: 'transparent', color: '#fff', fontSize: 22, border: 'none', outline: 'none', fontFamily: 'inherit' }} />
              <button onClick={() => d({ type: 'TOGGLE_SRCH' })} style={{ color: 'var(--muted)', fontSize: 24, padding: '0 8px' }}>✕</button>
            </div>
          </div>
        </div>
      )}

      <CartDrawer />
    </>
  )
}
