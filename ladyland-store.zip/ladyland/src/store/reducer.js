/**
 * Lady Land — App State Reducer
 * Pure function, no side effects. All DB writes happen in components/pages.
 */

export const initState = () => ({
  ready:          false,
  page:           'shop',     // shop | product | admin | checkout | done | wish
  adminTab:       'dash',     // dash | products | orders | settings
  products:       [],
  orders:         [],
  settings:       {},
  cart:           [],
  wish:           [],
  currentProd:    null,
  filterCat:      null,
  filterSort:     'newest',
  filterPriceMax: 10_000_000,
  filterColors:   [],
  searchQ:        '',
  cartOpen:       false,
  searchOpen:     false,
  toast:          null,
  ckStep:         1,
  ckAddr:         {},
  ckShip:         'standard',
})

/** @param {ReturnType<typeof initState>} s  @param {Object} a */
export function appReducer(s, a) {
  switch (a.type) {

    // ── Boot ──────────────────────────────────────────────
    case 'BOOT':
      return { ...s, ready: true, products: a.products, orders: a.orders, settings: a.settings }

    // ── Navigation ────────────────────────────────────────
    case 'PAGE':
      return { ...s, page: a.p, cartOpen: false, searchOpen: false }
    case 'OPEN_PROD':
      return { ...s, page: 'product', currentProd: a.p, cartOpen: false }
    case 'ADMIN_TAB':
      return { ...s, adminTab: a.tab }

    // ── Remote data ───────────────────────────────────────
    case 'SET_PRODUCTS': return { ...s, products: a.list }
    case 'SET_ORDERS':   return { ...s, orders:   a.list }
    case 'SET_SETTINGS': return { ...s, settings: a.s }

    // ── Filters ───────────────────────────────────────────
    case 'FCAT':   return { ...s, filterCat: a.v }
    case 'FSORT':  return { ...s, filterSort: a.v }
    case 'FPRICE': return { ...s, filterPriceMax: a.v }
    case 'FCOLOR': {
      const fc = s.filterColors.includes(a.c)
        ? s.filterColors.filter(x => x !== a.c)
        : [...s.filterColors, a.c]
      return { ...s, filterColors: fc }
    }
    case 'SEARCH': return { ...s, searchQ: a.q }

    // ── UI toggles ────────────────────────────────────────
    case 'TOGGLE_CART': return { ...s, cartOpen:   !s.cartOpen }
    case 'TOGGLE_SRCH': return { ...s, searchOpen: !s.searchOpen }

    // ── Cart ──────────────────────────────────────────────
    case 'CART_ADD': {
      const key    = `${a.pid}||${a.color}||${a.size}`
      const exists = s.cart.find(i => i.key === key)
      const cart   = exists
        ? s.cart.map(i => i.key === key ? { ...i, qty: i.qty + a.qty } : i)
        : [...s.cart, { key, pid: a.pid, name: a.name, unitPrice: a.unitPrice, color: a.color, size: a.size, qty: a.qty, thumb: a.thumb }]
      return { ...s, cart, toast: { msg: 'به سبد افزوده شد ✓', ok: true } }
    }
    case 'CART_DEL':   return { ...s, cart: s.cart.filter(i => i.key !== a.key) }
    case 'CART_QTY':   return { ...s, cart: s.cart.map(i => i.key === a.key ? { ...i, qty: Math.max(1, a.qty) } : i) }
    case 'CART_CLEAR': return { ...s, cart: [] }
    case 'CART_LOAD':  return { ...s, cart: a.cart }

    // ── Wishlist ──────────────────────────────────────────
    case 'WISH_TOGGLE': {
      const has  = s.wish.some(p => p.id === a.p.id)
      const wish = has ? s.wish.filter(p => p.id !== a.p.id) : [...s.wish, a.p]
      return { ...s, wish, toast: { msg: has ? 'از علاقه‌مندی حذف شد' : 'به علاقه‌مندی افزوده شد ♡', ok: true } }
    }
    case 'WISH_LOAD': return { ...s, wish: a.wish }

    // ── Orders ────────────────────────────────────────────
    case 'ORDER_PLACED':
      return { ...s, orders: [a.order, ...s.orders], cart: [], page: 'done', ckStep: 1,
               toast: { msg: 'سفارش ثبت شد ✓', ok: true } }
    case 'ORDER_STATUS':
      return { ...s, orders: s.orders.map(o => o.id === a.id ? { ...o, status: a.status } : o) }

    // ── Checkout ──────────────────────────────────────────
    case 'CK_ADDR': return { ...s, ckAddr: a.v }
    case 'CK_SHIP': return { ...s, ckShip: a.v }
    case 'CK_STEP': return { ...s, ckStep: a.n }

    // ── Toast ─────────────────────────────────────────────
    case 'TOAST':       return { ...s, toast: a.payload }
    case 'CLEAR_TOAST': return { ...s, toast: null }

    default: return s
  }
}
