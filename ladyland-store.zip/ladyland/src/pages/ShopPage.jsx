import { useApp } from '../store/context'
import { CATS, PALETTE_COLORS } from '../constants'
import { salePrice } from '../services/helpers'
import ProductCard from '../components/ProductCard'

export default function ShopPage() {
  const { s, d } = useApp()

  // ── Client-side filtering ──
  let prods = [...s.products]
  if (s.filterCat)          prods = prods.filter(p => p.category === s.filterCat)
  if (s.searchQ) {
    const q = s.searchQ
    prods = prods.filter(p =>
      p.name.includes(q) ||
      (p.nameEn || '').toLowerCase().includes(q.toLowerCase()) ||
      (p.description || '').includes(q)
    )
  }
  if (s.filterColors.length)  prods = prods.filter(p => p.colors?.some(c => s.filterColors.includes(c)))
  prods = prods.filter(p => salePrice(p) <= s.filterPriceMax)
  if (s.filterSort === 'newest')    prods.sort((a, b) => b.createdAt - a.createdAt)
  if (s.filterSort === 'priceAsc')  prods.sort((a, b) => salePrice(a) - salePrice(b))
  if (s.filterSort === 'priceDesc') prods.sort((a, b) => salePrice(b) - salePrice(a))
  if (s.filterSort === 'sale')      prods = prods.filter(p => p.discount > 0)
  if (s.filterSort === 'best')      prods = prods.filter(p => p.isBestseller)

  return (
    <div>
      {/* ── Hero strip ── */}
      <div style={{ background: 'var(--ink)', padding: '72px 32px', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 1, background: 'linear-gradient(90deg,transparent,var(--gold),transparent)' }} />
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: 1, background: 'linear-gradient(90deg,transparent,var(--gold),transparent)' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 0%,rgba(196,160,82,.08) 0%,transparent 70%)' }} />
        <p style={{ fontSize: 10, letterSpacing: 6, color: 'var(--gold)', marginBottom: 20 }} className="anim-fadeUp">✦ {s.settings.heroEn || 'SPRING — SUMMER COLLECTION'}</p>
        <h1 className="serif-i anim-fadeUp d2" style={{ fontSize: 'clamp(36px,5vw,68px)', color: 'var(--ivory)', fontWeight: 400, lineHeight: 1.05, marginBottom: 18 }}>
          {s.settings.heroTitle || 'کالکشن جدید'}
        </h1>
        <div className="gold-line anim-fadeUp d3" />
        <p className="anim-fadeUp d4" style={{ fontSize: 14, color: 'var(--muted)', fontWeight: 300, maxWidth: 480, margin: '0 auto 36px' }}>
          {s.settings.heroCopy}
        </p>
        <button className="btn btn-ghost anim-fadeUp d5" style={{ borderColor: 'rgba(255,255,255,.2)', color: 'var(--ivory)' }}>
          مشاهده کالکشن →
        </button>
      </div>

      {/* ── Category tabs ── */}
      <div style={{ borderBottom: '1px solid var(--border)', background: 'var(--white)' }}>
        <div style={{ maxWidth: 1320, margin: '0 auto', padding: '0 32px', display: 'flex', gap: 0, overflowX: 'auto' }}>
          {[{ id: null, fa: 'همه' }, ...CATS].map(c => (
            <button key={c.id ?? ''} onClick={() => d({ type: 'FCAT', v: c.id })}
              style={{ padding: '16px 22px', fontSize: 12, letterSpacing: .5, whiteSpace: 'nowrap', color: s.filterCat === c.id ? 'var(--ink)' : 'var(--gray)', borderBottom: `2px solid ${s.filterCat === c.id ? 'var(--gold)' : 'transparent'}`, transition: 'all .2s' }}>
              {c.fa}
            </button>
          ))}
        </div>
      </div>

      <div style={{ maxWidth: 1320, margin: '0 auto', padding: '48px 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', gap: 48 }}>

          {/* ── Sidebar ── */}
          <aside className="hide-sm" style={{ fontSize: 13 }}>
            <div style={{ position: 'sticky', top: 90 }}>
              <p className="serif-i" style={{ fontSize: 18, marginBottom: 24, paddingBottom: 12, borderBottom: '1px solid var(--border)' }}>فیلترها</p>

              {/* Sort */}
              <div style={{ marginBottom: 28 }}>
                <p style={{ fontSize: 9, letterSpacing: 3, color: 'var(--gold)', marginBottom: 14, fontWeight: 600 }}>SORT BY</p>
                {[['newest', 'جدیدترین'], ['priceAsc', 'ارزان‌ترین'], ['priceDesc', 'گران‌ترین'], ['sale', 'تخفیف‌دار'], ['best', 'پرفروش']].map(([v, l]) => (
                  <button key={v} onClick={() => d({ type: 'FSORT', v })}
                    style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', textAlign: 'right', padding: '7px 0', borderBottom: '1px solid var(--border)', color: s.filterSort === v ? 'var(--ink)' : 'var(--gray)', transition: 'color .2s' }}>
                    <span style={{ width: 7, height: 7, borderRadius: '50%', flexShrink: 0, background: s.filterSort === v ? 'var(--gold)' : 'transparent', border: `1.5px solid ${s.filterSort === v ? 'var(--gold)' : 'var(--muted)'}` }} />
                    {l}
                  </button>
                ))}
              </div>

              {/* Colors */}
              <div style={{ marginBottom: 28 }}>
                <p style={{ fontSize: 9, letterSpacing: 3, color: 'var(--gold)', marginBottom: 14, fontWeight: 600 }}>رنگ</p>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {Object.entries(PALETTE_COLORS).map(([n, h]) => (
                    <button key={n} title={n} onClick={() => d({ type: 'FCOLOR', c: n })}
                      style={{ width: 24, height: 24, borderRadius: '50%', background: h, border: `2.5px solid ${s.filterColors.includes(n) ? 'var(--gold)' : 'var(--border)'}`, transition: 'border .2s' }} />
                  ))}
                </div>
              </div>

              {/* Price */}
              <div>
                <p style={{ fontSize: 9, letterSpacing: 3, color: 'var(--gold)', marginBottom: 14, fontWeight: 600 }}>حداکثر قیمت</p>
                <input type="range" min={500000} max={10000000} step={200000}
                  value={s.filterPriceMax} onChange={e => d({ type: 'FPRICE', v: +e.target.value })} />
                <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8 }}>
                  {new Intl.NumberFormat('fa-IR').format(s.filterPriceMax)} تومان
                </p>
              </div>

              {/* Clear */}
              {(s.filterCat || s.filterColors.length || s.filterSort !== 'newest') && (
                <button className="btn btn-ghost btn-sm" style={{ marginTop: 24, width: '100%' }}
                  onClick={() => { d({ type: 'FCAT', v: null }); d({ type: 'FSORT', v: 'newest' }); d({ type: 'FPRICE', v: 10_000_000 }); d({ type: 'SEARCH', q: '' }) }}>
                  حذف فیلترها
                </button>
              )}
            </div>
          </aside>

          {/* ── Grid ── */}
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
              <span style={{ fontSize: 13, color: 'var(--gray)' }}>{prods.length} محصول</span>
            </div>
            {prods.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '100px 0', color: 'var(--muted)' }}>
                <div style={{ fontSize: 40, marginBottom: 16, opacity: .2 }}>◈</div>
                <p style={{ fontSize: 16, marginBottom: 8 }}>محصولی یافت نشد</p>
                <p style={{ fontSize: 13 }}>محصولات را از پنل مدیریت اضافه کنید</p>
              </div>
            ) : (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(230px,1fr))', gap: 24 }}>
                {prods.map((p, i) => <ProductCard key={p.id} p={p} idx={i} />)}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
