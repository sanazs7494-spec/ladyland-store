/**
 * Lady Land — Database Service
 * ─────────────────────────────────────────────────────────────────
 * CURRENT:  localStorage (works in any browser, no server needed)
 * FUTURE:   swap this file for supabase.js — zero changes elsewhere
 *
 * To migrate to Supabase:
 *   1. npm install @supabase/supabase-js
 *   2. Replace each function body with the equivalent Supabase query
 *   3. Images: upload file to supabase.storage, store public URL (not base64)
 * ─────────────────────────────────────────────────────────────────
 *
 * @typedef {Object} Product
 * @property {string}   id
 * @property {string}   name
 * @property {string}   nameEn
 * @property {string}   category   - clothing | bags | shoes | acc
 * @property {string}   code
 * @property {number}   price
 * @property {number}   discount   - 0–90
 * @property {string}   material
 * @property {string}   description
 * @property {string[]} colors
 * @property {string[]} sizes
 * @property {Object}   inventory  - { "S-مشکی": 5, ... }
 * @property {string[]} images     - base64 now; URLs after Supabase migration
 * @property {boolean}  isNew
 * @property {boolean}  isBestseller
 * @property {number}   createdAt
 *
 * @typedef {Object} Order
 * @property {string}   id
 * @property {any[]}    items
 * @property {number}   total
 * @property {Object}   addr
 * @property {string}   ship
 * @property {string}   status
 * @property {string}   date
 * @property {number}   ts
 *
 * @typedef {Object} Settings
 * @property {string} heroTitle
 * @property {string} heroEn
 * @property {string} heroCopy
 * @property {string} ticker
 */

// ── Storage keys ──────────────────────────────────────────────
const KEYS = {
  products: 'ladyland__products',
  orders:   'ladyland__orders',
  settings: 'ladyland__settings',
  cart:     'ladyland__cart',
  wishlist: 'ladyland__wishlist',
}

// ── Low-level helpers ─────────────────────────────────────────
function lsGet(key) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

function lsSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
    return true
  } catch (e) {
    console.error('[DB] localStorage write failed:', e)
    return false
  }
}

function lsDel(key) {
  try { localStorage.removeItem(key) } catch {}
}

// ─────────────────────────────────────────────────────────────
// PRODUCTS
// ─────────────────────────────────────────────────────────────

/** @returns {Promise<Product[]>} */
export async function getProducts() {
  return lsGet(KEYS.products) ?? []
}

/** @param {Product[]} list */
export async function saveProducts(list) {
  return lsSet(KEYS.products, list)
}

/** @param {Product} product */
export async function addProduct(product) {
  const list = await getProducts()
  const next = [product, ...list]
  lsSet(KEYS.products, next)
  return next
}

/** @param {Product} product */
export async function updateProduct(product) {
  const list = await getProducts()
  const next = list.map(p => p.id === product.id ? product : p)
  lsSet(KEYS.products, next)
  return next
}

/** @param {string} id */
export async function deleteProduct(id) {
  const list = await getProducts()
  const next = list.filter(p => p.id !== id)
  lsSet(KEYS.products, next)
  return next
}

/** @param {string} query  @param {string|null} category */
export async function searchProducts(query, category = null) {
  let list = await getProducts()
  if (category) list = list.filter(p => p.category === category)
  if (query) {
    const q = query.toLowerCase()
    list = list.filter(p =>
      p.name.includes(query) ||
      (p.nameEn || '').toLowerCase().includes(q) ||
      (p.description || '').includes(query) ||
      (p.code || '').toLowerCase().includes(q)
    )
  }
  return list
}

// ─────────────────────────────────────────────────────────────
// ORDERS
// ─────────────────────────────────────────────────────────────

/** @returns {Promise<Order[]>} */
export async function getOrders() {
  return lsGet(KEYS.orders) ?? []
}

/** @param {Order[]} list */
export async function saveOrders(list) {
  return lsSet(KEYS.orders, list)
}

/** @param {Order} order */
export async function addOrder(order) {
  const list = await getOrders()
  const next = [order, ...list]
  lsSet(KEYS.orders, next)
  return next
}

/** @param {string} id  @param {string} status */
export async function updateOrderStatus(id, status) {
  const list = await getOrders()
  const next = list.map(o => o.id === id ? { ...o, status } : o)
  lsSet(KEYS.orders, next)
  return next
}

// ─────────────────────────────────────────────────────────────
// SETTINGS
// ─────────────────────────────────────────────────────────────

/** @returns {Promise<Settings|null>} */
export async function getSettings() {
  return lsGet(KEYS.settings)
}

/** @param {Settings} obj */
export async function saveSettings(obj) {
  return lsSet(KEYS.settings, obj)
}

// ─────────────────────────────────────────────────────────────
// CART  (persisted to survive page refresh)
// ─────────────────────────────────────────────────────────────

export function getCartLocal() {
  return lsGet(KEYS.cart) ?? []
}

export function saveCartLocal(cart) {
  lsSet(KEYS.cart, cart)
}

// ─────────────────────────────────────────────────────────────
// WISHLIST (persisted)
// ─────────────────────────────────────────────────────────────

export function getWishlistLocal() {
  return lsGet(KEYS.wishlist) ?? []
}

export function saveWishlistLocal(list) {
  lsSet(KEYS.wishlist, list)
}

// ─────────────────────────────────────────────────────────────
// IMAGE HELPERS
// ─────────────────────────────────────────────────────────────

/** Read a File and return base64 data URL */
export async function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload  = e => resolve(e.target.result)
    reader.onerror = () => reject(new Error('Failed to read file'))
    reader.readAsDataURL(file)
  })
}

/**
 * Upload images (currently: convert to base64)
 * FUTURE: upload to Supabase Storage, return public URLs
 *
 * @param {File[]} files
 * @param {number} maxSizeMB
 * @returns {Promise<string[]>}
 */
export async function uploadImages(files, maxSizeMB = 3.5) {
  const results = []
  const maxBytes = maxSizeMB * 1024 * 1024

  for (const file of files) {
    if (!file.type.startsWith('image/')) {
      console.warn(`Skipping non-image: ${file.name}`)
      continue
    }
    if (file.size > maxBytes) {
      throw new Error(`${file.name} بزرگ‌تر از ${maxSizeMB} مگابایت است`)
    }
    const b64 = await readFileAsBase64(file)
    results.push(b64)
  }
  return results
}

// ─────────────────────────────────────────────────────────────
// RESET (dev/testing)
// ─────────────────────────────────────────────────────────────

export function resetDatabase() {
  Object.values(KEYS).forEach(lsDel)
}
