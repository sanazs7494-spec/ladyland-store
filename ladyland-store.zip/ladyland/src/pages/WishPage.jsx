import { useApp } from '../store/context'
import ProductCard from '../components/ProductCard'

export default function WishPage() {
  const { s, d } = useApp()

  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '48px 32px' }}>
      <div style={{ textAlign: 'center', marginBottom: 48 }}>
        <p style={{ fontSize: 9, letterSpacing: 5, color: 'var(--gold)', marginBottom: 10, fontWeight: 600 }}>WISHLIST</p>
        <h1 className="serif-i" style={{ fontSize: 36, fontWeight: 400 }}>علاقه‌مندی‌ها</h1>
        <div className="gold-line" />
      </div>

      {s.wish.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '80px 0', color: 'var(--muted)' }}>
          <div style={{ fontSize: 40, marginBottom: 16, opacity: .2 }}>♡</div>
          <p style={{ fontSize: 16, marginBottom: 24 }}>لیست علاقه‌مندی خالی است</p>
          <button className="btn btn-ink" onClick={() => d({ type: 'PAGE', p: 'shop' })}>
            مشاهده محصولات
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(230px,1fr))', gap: 24 }}>
          {s.wish.map((p, i) => <ProductCard key={p.id} p={p} idx={i} />)}
        </div>
      )}
    </div>
  )
}
