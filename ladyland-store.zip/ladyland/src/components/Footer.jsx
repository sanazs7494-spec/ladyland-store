import { useApp } from '../store/context'
import { CATS } from '../constants'

function Ticker({ text }) {
  const rep = text + ' · ' + text + ' · '
  return (
    <div style={{ background: 'var(--ink)', overflow: 'hidden', height: 34, display: 'flex', alignItems: 'center' }}>
      <div style={{ display: 'flex', whiteSpace: 'nowrap', animation: 'tickerMove 22s linear infinite' }}>
        {[...Array(4)].map((_, i) => (
          <span key={i} style={{ fontSize: 11, letterSpacing: 1.2, color: 'var(--muted)', paddingLeft: 40 }}>{rep}</span>
        ))}
      </div>
    </div>
  )
}

export { Ticker }

export default function Footer() {
  const { s, d } = useApp()

  return (
    <footer style={{ background: 'var(--ink)', color: 'rgba(255,255,255,.5)', padding: '52px 32px 24px' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(180px,1fr))', gap: 36, marginBottom: 40, paddingBottom: 40, borderBottom: '1px solid rgba(255,255,255,.07)' }}>
          <div>
            <div className="serif-i" style={{ color: '#fff', fontSize: 20, marginBottom: 3 }}>Lady Land</div>
            <div style={{ fontSize: 8, letterSpacing: 4, color: 'var(--gold)', marginBottom: 14 }}>LUXURY FASHION</div>
            <p style={{ fontSize: 12, lineHeight: 1.9 }}>مقصد اول خرید فشن لاکچری زنانه در ایران</p>
          </div>

          {[['محصولات', CATS.map(c => c.fa)], ['خدمات', ['درباره ما', 'تماس با ما', 'راهنمای سایز', 'پیگیری سفارش']]].map(([h, ls]) => (
            <div key={h}>
              <p style={{ fontSize: 9, letterSpacing: 3, color: 'var(--gold)', marginBottom: 14, fontWeight: 600 }}>{h}</p>
              {ls.map(l => (
                <p key={l} style={{ fontSize: 12, marginBottom: 9, cursor: 'pointer', transition: 'color .2s' }}
                  onMouseEnter={e => e.target.style.color = '#fff'}
                  onMouseLeave={e => e.target.style.color = 'rgba(255,255,255,.5)'}>{l}</p>
              ))}
            </div>
          ))}

          <div>
            <p style={{ fontSize: 9, letterSpacing: 3, color: 'var(--gold)', marginBottom: 14, fontWeight: 600 }}>تماس</p>
            {[['◈', 'تهران، ولیعصر'], ['◉', '۰۲۱-۸۸۰۰-۰۰۰۰'], ['◇', 'info@ladyland.ir']].map(([ic, t]) => (
              <p key={t} style={{ fontSize: 12, marginBottom: 9, display: 'flex', gap: 8 }}>
                <span style={{ color: 'var(--gold)' }}>{ic}</span>{t}
              </p>
            ))}
          </div>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12, fontSize: 11 }}>
          <span>© ۱۴۰۴ لیدی لند — تمامی حقوق محفوظ است</span>
          <button
            onClick={() => d({ type: 'PAGE', p: 'admin' })}
            style={{ fontSize: 10, letterSpacing: 2, color: 'rgba(255,255,255,.15)', transition: 'color .2s' }}
            onMouseEnter={e => e.currentTarget.style.color = 'var(--gold)'}
            onMouseLeave={e => e.currentTarget.style.color = 'rgba(255,255,255,.15)'}
          >ADMIN ↗</button>
        </div>
      </div>
    </footer>
  )
}
