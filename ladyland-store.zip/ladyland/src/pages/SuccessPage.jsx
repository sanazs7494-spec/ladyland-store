import { useApp } from '../store/context'
import { money } from '../services/helpers'
import { ORDER_STATUS } from '../constants'

export default function SuccessPage() {
  const { s, d } = useApp()
  const o = s.orders[0]

  return (
    <div className="anim-fadeIn"
      style={{ maxWidth: 520, margin: '80px auto', padding: '0 32px', textAlign: 'center' }}>

      <div style={{
        width: 68, height: 68, borderRadius: '50%',
        background: 'var(--green)', color: '#fff',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 28, margin: '0 auto 28px',
      }}>✓</div>

      <h1 className="serif-i" style={{ fontSize: 40, fontWeight: 400, marginBottom: 10 }}>
        سفارش ثبت شد
      </h1>
      <p style={{ color: 'var(--muted)', marginBottom: 8, fontSize: 14 }}>از خرید شما متشکریم</p>

      {o && (
        <p style={{ fontSize: 12, color: 'var(--gold)', marginBottom: 32, fontFamily: 'monospace', letterSpacing: 1 }}>
          شماره پیگیری: <strong>{o.id}</strong>
        </p>
      )}

      <div style={{ background: 'var(--cream)', padding: 22, marginBottom: 32, textAlign: 'right', fontSize: 13, lineHeight: 2 }}>
        <p><span style={{ color: 'var(--muted)' }}>تاریخ:</span> {o?.date}</p>
        <p>
          <span style={{ color: 'var(--muted)' }}>وضعیت:</span>{' '}
          <span style={{ color: ORDER_STATUS.new.color }}>سفارش جدید</span>
        </p>
        <p><span style={{ color: 'var(--muted)' }}>مبلغ:</span> {o && money(o.total)}</p>
      </div>

      <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
        <button className="btn btn-ghost"
          onClick={() => { d({ type: 'ADMIN_TAB', tab: 'orders' }); d({ type: 'PAGE', p: 'admin' }) }}>
          پیگیری سفارش
        </button>
        <button className="btn btn-ink" onClick={() => d({ type: 'PAGE', p: 'shop' })}>
          بازگشت به فروشگاه
        </button>
      </div>
    </div>
  )
}
