import { useReducer, useCallback, useEffect } from 'react'
import { AppCtx } from './store/context'
import { appReducer, initState } from './store/reducer'
import {
  getProducts, saveProducts,
  getOrders,
  getSettings,
  getCartLocal, saveCartLocal,
  getWishlistLocal, saveWishlistLocal,
} from './services/database'
import { DEFAULT_SETTINGS, SEED_PRODUCTS } from './constants'

// Components
import Toast  from './components/Toast'
import Header from './components/Header'
import Footer, { Ticker } from './components/Footer'

// Pages
import ShopPage     from './pages/ShopPage'
import ProductPage  from './pages/ProductPage'
import AdminPage    from './pages/AdminPage'
import CheckoutPage from './pages/CheckoutPage'
import SuccessPage  from './pages/SuccessPage'
import WishPage     from './pages/WishPage'

// ── Boot screen ──────────────────────────────────────────────
function BootScreen() {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'var(--ivory)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      zIndex: 9000,
    }}>
      <div className="serif-i" style={{ fontSize: 34, color: 'var(--ink)', marginBottom: 18 }}>
        Lady Land
      </div>
      <div style={{ width: 40, height: 1, background: 'var(--gold)' }} />
    </div>
  )
}

// ── Root App ─────────────────────────────────────────────────
export default function App() {
  const [s, dispatch] = useReducer(appReducer, undefined, initState)
  const d = useCallback(action => dispatch(action), [])

  // ── Boot: load all data from localStorage ──────────────────
  useEffect(() => {
    ;(async () => {
      // Products — seed on first launch
      let products = await getProducts()
      if (!products || products.length === 0) {
        products = SEED_PRODUCTS
        await saveProducts(products)
      }

      // Orders & settings
      const orders   = await getOrders()
      const settings = await getSettings()

      // Cart & wishlist — persisted separately
      const cart     = getCartLocal()
      const wish     = getWishlistLocal()

      dispatch({
        type: 'BOOT',
        products,
        orders,
        settings: settings ?? DEFAULT_SETTINGS,
      })

      // Restore cart and wishlist
      if (cart.length > 0)  dispatch({ type: 'CART_LOAD', cart })
      if (wish.length > 0)  dispatch({ type: 'WISH_LOAD', wish })
    })()
  }, [])

  // ── Persist cart on every change (after boot) ──────────────
  useEffect(() => {
    if (s.ready) saveCartLocal(s.cart)
  }, [s.cart, s.ready])

  // ── Persist wishlist on every change ──────────────────────
  useEffect(() => {
    if (s.ready) saveWishlistLocal(s.wish)
  }, [s.wish, s.ready])

  // ── Loading screen ────────────────────────────────────────
  if (!s.ready) {
    return (
      <AppCtx.Provider value={{ s, d }}>
        <Toast />
        <BootScreen />
      </AppCtx.Provider>
    )
  }

  const isAdmin  = s.page === 'admin'
  const fullPage = ['admin', 'checkout', 'done'].includes(s.page)

  return (
    <AppCtx.Provider value={{ s, d }}>
      <Toast />

      {/* Ticker + Header — hidden on admin */}
      {!isAdmin && <Ticker text={s.settings.ticker || DEFAULT_SETTINGS.ticker} />}
      {!isAdmin && <Header />}

      {/* Page router */}
      <main style={{ minHeight: isAdmin ? '100vh' : 'calc(100vh - 103px)' }}>
        {s.page === 'shop'     && <ShopPage />}
        {s.page === 'product'  && <ProductPage />}
        {s.page === 'admin'    && <AdminPage />}
        {s.page === 'checkout' && <CheckoutPage />}
        {s.page === 'done'     && <SuccessPage />}
        {s.page === 'wish'     && <WishPage />}
      </main>

      {/* Footer — hidden on admin */}
      {!isAdmin && <Footer />}
    </AppCtx.Provider>
  )
}
