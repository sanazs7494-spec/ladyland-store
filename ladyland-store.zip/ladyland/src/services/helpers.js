/** Format price in Farsi */
export const money = n =>
  new Intl.NumberFormat('fa-IR').format(Math.round(n)) + ' تومان'

/** Final price after discount */
export const salePrice = p =>
  p.discount ? Math.round(p.price * (1 - p.discount / 100)) : p.price

/** Unique ID */
export const uid = () =>
  `${Date.now()}_${Math.random().toString(36).slice(2, 6)}`

/** Order ID */
export const orderId = () =>
  `LL-${uid().toUpperCase().slice(0, 10)}`
