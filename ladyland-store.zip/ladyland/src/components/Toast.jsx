import { useEffect } from 'react'
import { useApp } from '../store/context'

export default function Toast() {
  const { s, d } = useApp()

  useEffect(() => {
    if (!s.toast) return
    const t = setTimeout(() => d({ type: 'CLEAR_TOAST' }), 2800)
    return () => clearTimeout(t)
  }, [s.toast])

  if (!s.toast) return null

  return (
    <div style={{
      position: 'fixed', top: 24, left: '50%', transform: 'translateX(-50%)',
      zIndex: 9999,
      background: s.toast.ok ? 'var(--ink)' : 'var(--red)',
      color: '#fff', padding: '11px 24px', fontSize: 13, letterSpacing: .3,
      boxShadow: '0 8px 32px rgba(0,0,0,.22)',
      animation: 'toastDrop .3s ease',
      display: 'flex', alignItems: 'center', gap: 10, pointerEvents: 'none',
    }}>
      <span style={{ fontSize: 15 }}>{s.toast.ok ? '✓' : '✕'}</span>
      {s.toast.msg}
    </div>
  )
}
