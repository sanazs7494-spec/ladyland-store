import { useState } from 'react'
import { CATS, PALETTE_COLORS } from '../constants'
import { uid } from '../services/helpers'
import ImageUploader from './ImageUploader'

const EMPTY = {
  name: '', nameEn: '', category: 'clothing', code: '',
  price: '', discount: '0', material: '', description: '',
  colorsStr: 'مشکی,کرم', sizesStr: 'S,M,L,XL',
  images: [], isNew: false, isBestseller: false, inventory: {},
}

export default function ProductForm({ product, onSave, onCancel }) {
  const isEdit = !!product
  const [f, setF] = useState(() => {
    if (!product) return { ...EMPTY }
    return {
      ...EMPTY, ...product,
      colorsStr: product.colors?.join(',') || '',
      sizesStr:  product.sizes?.join(',')  || '',
      price:     String(product.price),
      discount:  String(product.discount || 0),
    }
  })
  const [saving,    setSaving]    = useState(false)
  const [activeTab, setActiveTab] = useState('basic')
  const [formError, setFormError] = useState('')

  const upF = (k, v) => setF(x => ({ ...x, [k]: v }))

  const colorList = f.colorsStr.split(',').map(s => s.trim()).filter(Boolean)
  const sizeList  = f.sizesStr.split(',').map(s => s.trim()).filter(Boolean)

  const invKeys = sizeList.length > 0
    ? sizeList.flatMap(sz => colorList.map(cl => `${sz}-${cl}`))
    : colorList

  const setInv = (k, v) => setF(x => ({ ...x, inventory: { ...x.inventory, [k]: Math.max(0, +v || 0) } }))

  const save = async () => {
    setFormError('')
    if (!f.name.trim()) { setFormError('نام محصول الزامی است'); setActiveTab('basic'); return }
    if (!f.price || isNaN(+f.price)) { setFormError('قیمت معتبر وارد کنید'); setActiveTab('basic'); return }
    setSaving(true)
    const p = {
      ...product,
      id:           product?.id || uid(),
      name:         f.name.trim(),
      nameEn:       f.nameEn.trim(),
      category:     f.category,
      code:         f.code.trim(),
      price:        Math.round(+f.price),
      discount:     Math.max(0, Math.min(90, +f.discount || 0)),
      material:     f.material.trim(),
      description:  f.description.trim(),
      colors:       colorList,
      sizes:        sizeList,
      inventory:    f.inventory,
      images:       f.images,
      isNew:        f.isNew,
      isBestseller: f.isBestseller,
      createdAt:    product?.createdAt || Date.now(),
    }
    await onSave(p)
    setSaving(false)
  }

  const Field = ({ label, name, type = 'text', placeholder = '' }) => (
    <div>
      <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 6, letterSpacing: .3 }}>{label}</label>
      <input className="inp" type={type} value={f[name] || ''} placeholder={placeholder}
        onChange={e => upF(name, e.target.value)} />
    </div>
  )

  const TABS = [
    ['basic',     'اطلاعات اصلی'],
    ['images',    `تصاویر (${f.images.length})`],
    ['inventory', 'موجودی'],
  ]

  return (
    <div className="anim-fadeUp" style={{ background: '#fff', border: '1px solid var(--border)', padding: 28, marginBottom: 28 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, paddingBottom: 16, borderBottom: '1px solid var(--border)' }}>
        <h3 className="serif-i" style={{ fontSize: 22 }}>{isEdit ? 'ویرایش محصول' : 'محصول جدید'}</h3>
        <button onClick={onCancel} style={{ color: 'var(--muted)', fontSize: 22, lineHeight: 1 }}>✕</button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', marginBottom: 24 }}>
        {TABS.map(([k, l]) => (
          <button key={k} onClick={() => setActiveTab(k)}
            style={{ padding: '10px 20px', fontSize: 12, letterSpacing: .3, color: activeTab === k ? 'var(--ink)' : 'var(--muted)', borderBottom: `2px solid ${activeTab === k ? 'var(--gold)' : 'transparent'}`, transition: 'all .2s' }}>
            {l}
          </button>
        ))}
      </div>

      {formError && (
        <div style={{ background: '#FFF0F0', border: '1px solid var(--red)', padding: '10px 14px', fontSize: 12, color: 'var(--red)', marginBottom: 16 }}>
          {formError}
        </div>
      )}

      {/* ── Basic info ── */}
      {activeTab === 'basic' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <Field label="نام محصول (فارسی) *" name="name" />
          <Field label="نام انگلیسی" name="nameEn" />
          <div>
            <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 6 }}>دسته‌بندی</label>
            <select value={f.category} onChange={e => upF('category', e.target.value)}
              style={{ width: '100%', padding: '11px 15px', border: '1.5px solid var(--border)', background: '#fff', fontSize: 13, fontFamily: 'inherit' }}>
              {CATS.map(c => <option key={c.id} value={c.id}>{c.fa}</option>)}
            </select>
          </div>
          <Field label="کد محصول" name="code" placeholder="مثلاً LL-C001" />
          <Field label="قیمت (تومان) *" name="price" type="number" />
          <Field label="تخفیف ٪ (۰ تا ۹۰)" name="discount" type="number" />
          <Field label="جنس / متریال" name="material" placeholder="مثلاً ابریشم ایتالیایی" />
          <div>
            <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 6 }}>رنگ‌ها (با ویرگول)</label>
            <input className="inp" value={f.colorsStr} onChange={e => upF('colorsStr', e.target.value)} placeholder="مشکی,کرم,طلایی" />
            <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap', marginTop: 6 }}>
              {colorList.map(c => (
                <span key={c} title={c} style={{ width: 14, height: 14, borderRadius: '50%', background: PALETTE_COLORS[c] || '#ccc', border: '1.5px solid var(--border)', display: 'inline-block' }} />
              ))}
            </div>
          </div>
          <div>
            <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 6 }}>سایزها (با ویرگول، خالی برای بدون سایز)</label>
            <input className="inp" value={f.sizesStr} onChange={e => upF('sizesStr', e.target.value)} placeholder="XS,S,M,L,XL یا 36,37,38" />
          </div>
          <div style={{ gridColumn: 'span 2' }}>
            <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 6 }}>توضیحات</label>
            <textarea value={f.description} onChange={e => upF('description', e.target.value)}
              rows={3} style={{ width: '100%', padding: '11px 15px', border: '1.5px solid var(--border)', fontSize: 13, resize: 'vertical', fontFamily: 'inherit' }} />
          </div>
          <div style={{ gridColumn: 'span 2', display: 'flex', gap: 28 }}>
            {[['isNew', 'محصول جدید'], ['isBestseller', 'پرفروش']].map(([k, l]) => (
              <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, cursor: 'pointer' }}>
                <input type="checkbox" checked={!!f[k]} onChange={e => upF(k, e.target.checked)} style={{ accentColor: 'var(--gold)', width: 15, height: 15 }} />
                {l}
              </label>
            ))}
          </div>
        </div>
      )}

      {/* ── Images ── */}
      {activeTab === 'images' && (
        <div>
          <p style={{ fontSize: 13, color: 'var(--gray)', marginBottom: 16, lineHeight: 1.7 }}>
            اولین تصویر به عنوان کاور نمایش داده می‌شود. ترتیب با دکمه ← قابل تغییر است.
          </p>
          <ImageUploader images={f.images} onChange={imgs => upF('images', imgs)} />
        </div>
      )}

      {/* ── Inventory ── */}
      {activeTab === 'inventory' && (
        <div>
          {invKeys.length === 0 ? (
            <p style={{ color: 'var(--muted)', fontSize: 13, padding: '20px 0' }}>
              ابتدا رنگ‌ها (و سایزها) را در تب «اطلاعات اصلی» وارد کنید.
            </p>
          ) : (
            <>
              <p style={{ fontSize: 12, color: 'var(--gray)', marginBottom: 16 }}>تعداد موجودی هر ترکیب:</p>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: 10 }}>
                {invKeys.map(key => {
                  const parts = key.split('-')
                  const cl    = sizeList.length > 0 ? parts.slice(1).join('-') : key
                  return (
                    <div key={key} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', background: 'var(--cream)', border: '1px solid var(--border)' }}>
                      <div style={{ width: 14, height: 14, borderRadius: '50%', background: PALETTE_COLORS[cl] || '#ccc', border: '1px solid var(--border)', flexShrink: 0 }} />
                      <span style={{ flex: 1, fontSize: 12, color: 'var(--char)' }}>{key}</span>
                      <input type="number" min="0" value={f.inventory[key] ?? 0}
                        onChange={e => setInv(key, e.target.value)}
                        style={{ width: 60, padding: '5px 8px', border: '1px solid var(--border)', textAlign: 'center', fontSize: 13 }} />
                    </div>
                  )
                })}
              </div>
            </>
          )}
        </div>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', gap: 12, marginTop: 24, paddingTop: 20, borderTop: '1px solid var(--border)' }}>
        <button className="btn btn-gold" onClick={save} disabled={saving} style={{ opacity: saving ? .6 : 1 }}>
          {saving ? 'در حال ذخیره...' : isEdit ? 'ذخیره تغییرات' : 'افزودن محصول'}
        </button>
        <button className="btn btn-ghost" onClick={onCancel}>انصراف</button>
      </div>
    </div>
  )
}
