import { useState, useEffect } from 'react'
import { useApp } from '../store/context'
import { SHIP_OPTS } from '../constants'
import { money } from '../services/helpers'
import { addOrder } from '../services/database'
import { orderId } from '../services/helpers'

function Step({ n, label, active, done }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{
        width: 36, height: 36, borderRadius: '50%', margin: '0 auto 6px',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 12, fontWeight: 600,
        background: done ? 'var(--gold)' : active ? 'var(--ink)' : 'transparent',
        color: (done || active) ? '#fff' : 'var(--muted)',
        border: `1.5px solid ${done || active ? 'transparent' : 'var(--border)'}`,
      }}>
        {done ? '✓' : n}
      </div>
      <div style={{ fontSize: 11, color: active ? 'var(--ink)' : 'var(--muted)' }}>{label}</div>
    </div>
  )
}

export default function CheckoutPage() {
  const { s, d } = useApp()

  const [addr, setAddr] = useState(s.ckAddr || {})
  const upAddr = (k, v) => setAddr(a => ({ ...a, [k]: v }))

  const ship     = SHIP_OPTS.find(x => x.id === s.ckShip) ?? SHIP_OPTS[1]
  const subtotal = s.cart.reduce((a, i) => a + i.unitPrice * i.qty, 0)
  const total    = subtotal + ship.cost

  // Redirect if cart is empty
  useEffect(() => {
    if (s.cart.length === 0 && s.page === 'checkout') {
      d({ type: 'PAGE', p: 'shop' })
    }
  }, [s.cart.length])

  const placeOrder = async () => {
    const order = {
      id:     orderId(),
      items:  [...s.cart],
      total,
      addr,
      ship:   s.ckShip,
      status: 'new',
      date:   new Date().toLocaleDateString('fa-IR'),
      ts:     Date.now(),
    }
    const next = await addOrder(order)
    d({ type: 'SET_ORDERS', list: next })
    d({ type: 'ORDER_PLACED', order })
  }

  const OrderSummary = () => (
    <div style={{ background: 'var(--cream)', padding: 24, position: 'sticky', top: 88 }}>
      <p className="serif-i" style={{ fontSize: 20, marginBottom: 18 }}>خلاصه سفارش</p>
      {s.cart.map(i => (
        <div key={i.key} style={{ display: 'flex', gap: 10, padding: '10px 0', borderBottom: '1px solid var(--border)' }}>
          <div style={{ width: 52, height: 64, background: 'var(--warm)', flexShrink: 0, overflow: 'hidden' }}>
            {i.thumb
              ? <img src={i.thumb} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              : <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--muted)' }}>◈</div>}
          </div>
          <div style={{ flex: 1 }}>
            <p style={{ fontSize: 12, fontWeight: 500, marginBottom: 2 }}>{i.name}</p>
            <p style={{ fontSize: 11, color: 'var(--muted)' }}>
              {i.color}{i.size && i.size !== '—' ? ' / ' + i.size : ''} ×{i.qty}
            </p>
          </div>
          <span style={{ fontSize: 13, fontWeight: 600, whiteSpace: 'nowrap' }}>{money(i.unitPrice * i.qty)}</span>
        </div>
      ))}
      <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px 0', borderBottom: '1px solid var(--border)', fontSize: 13, color: 'var(--gray)' }}>
        <span>ارسال</span>
        <span>{ship.cost === 0 ? 'رایگان' : money(ship.cost)}</span>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: 12 }}>
        <strong>جمع کل</strong>
        <strong className="serif" style={{ fontSize: 20 }}>{money(total)}</strong>
      </div>
    </div>
  )

  return (
    <div className="anim-fadeIn" style={{ maxWidth: 1060, margin: '0 auto', padding: '48px 32px' }}>
      <h1 className="serif-i" style={{ fontSize: 34, textAlign: 'center', marginBottom: 48 }}>تکمیل خرید</h1>

      {/* Step indicator */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 0, marginBottom: 48 }}>
        {[['۱', 'آدرس'], ['۲', 'ارسال'], ['۳', 'پرداخت']].map(([n, l], i) => (
          <div key={n} style={{ display: 'flex', alignItems: 'center' }}>
            <Step n={n} label={l} active={s.ckStep === i + 1} done={s.ckStep > i + 1} />
            {i < 2 && (
              <div style={{ width: 56, height: 1, background: s.ckStep > i + 1 ? 'var(--gold)' : 'var(--border)', margin: '0 6px', marginBottom: 20 }} />
            )}
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 40 }}>
        <div>

          {/* Step 1 — Address */}
          {s.ckStep === 1 && (
            <div>
              <p className="serif-i" style={{ fontSize: 20, marginBottom: 22 }}>آدرس تحویل</p>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                {[['name', 'نام و نام خانوادگی'], ['phone', 'شماره موبایل'], ['province', 'استان'], ['city', 'شهر'], ['postal', 'کد پستی']].map(([k, l]) => (
                  <div key={k}>
                    <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 5 }}>{l}</label>
                    <input className="inp" value={addr[k] || ''} onChange={e => upAddr(k, e.target.value)} />
                  </div>
                ))}
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={{ fontSize: 11, color: 'var(--muted)', display: 'block', marginBottom: 5 }}>آدرس دقیق</label>
                  <textarea value={addr.address || ''} onChange={e => upAddr('address', e.target.value)}
                    rows={2}
                    style={{ width: '100%', padding: '11px 15px', border: '1.5px solid var(--border)', fontSize: 13, resize: 'vertical', fontFamily: 'inherit', outline: 'none', transition: 'border .2s' }}
                    onFocus={e => e.target.style.borderColor = 'var(--gold)'}
                    onBlur={e => e.target.style.borderColor = 'var(--border)'} />
                </div>
              </div>
              <button className="btn btn-ink" style={{ marginTop: 20 }}
                onClick={() => { d({ type: 'CK_ADDR', v: addr }); d({ type: 'CK_STEP', n: 2 }) }}>
                ادامه →
              </button>
            </div>
          )}

          {/* Step 2 — Shipping */}
          {s.ckStep === 2 && (
            <div>
              <p className="serif-i" style={{ fontSize: 20, marginBottom: 22 }}>روش ارسال</p>
              {SHIP_OPTS.map(opt => (
                <button key={opt.id} onClick={() => d({ type: 'CK_SHIP', v: opt.id })}
                  style={{
                    width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    padding: '16px 20px',
                    border: `1.5px solid ${s.ckShip === opt.id ? 'var(--gold)' : 'var(--border)'}`,
                    background: s.ckShip === opt.id ? 'rgba(196,160,82,.05)' : '#fff',
                    marginBottom: 10, transition: 'all .2s',
                  }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{
                      width: 16, height: 16, borderRadius: '50%',
                      border: `2px solid ${s.ckShip === opt.id ? 'var(--gold)' : 'var(--border)'}`,
                      background: s.ckShip === opt.id ? 'var(--gold)' : 'transparent',
                    }} />
                    <span style={{ fontSize: 13 }}>{opt.label}</span>
                  </div>
                  <span style={{ fontSize: 13, fontWeight: 600, color: opt.cost === 0 ? 'var(--green)' : 'var(--ink)' }}>
                    {opt.cost === 0 ? 'رایگان' : money(opt.cost)}
                  </span>
                </button>
              ))}
              <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
                <button className="btn btn-ghost" onClick={() => d({ type: 'CK_STEP', n: 1 })}>← برگشت</button>
                <button className="btn btn-ink"   onClick={() => d({ type: 'CK_STEP', n: 3 })}>ادامه →</button>
              </div>
            </div>
          )}

          {/* Step 3 — Payment */}
          {s.ckStep === 3 && (
            <div>
              <p className="serif-i" style={{ fontSize: 20, marginBottom: 22 }}>پرداخت</p>
              <div style={{ background: 'var(--cream)', padding: 18, fontSize: 13, marginBottom: 20 }}>
                <p style={{ color: 'var(--muted)', marginBottom: 4 }}>آدرس:</p>
                <p style={{ fontWeight: 500 }}>{addr.name} — {addr.city}، {addr.address}</p>
              </div>
              <div style={{ background: 'var(--ink)', color: '#fff', padding: 28, textAlign: 'center', marginBottom: 20 }}>
                <p style={{ fontSize: 10, letterSpacing: 4, color: 'var(--muted)', marginBottom: 8 }}>مبلغ قابل پرداخت</p>
                <p className="serif" style={{ fontSize: 38, fontWeight: 500 }}>{money(total)}</p>
              </div>
              <div style={{ display: 'flex', gap: 12 }}>
                <button className="btn btn-ghost" onClick={() => d({ type: 'CK_STEP', n: 2 })}>← برگشت</button>
                <button className="btn btn-gold" style={{ flex: 1 }} onClick={placeOrder}>
                  تأیید و پرداخت →
                </button>
              </div>
              <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 12, textAlign: 'center' }}>
                پرداخت امن · SSL · شتاب
              </p>
            </div>
          )}
        </div>

        <OrderSummary />
      </div>
    </div>
  )
}
