// ─── Lady Land — App Constants ────────────────────────────────

export const CATS = [
  { id: 'clothing', fa: 'لباس',     en: 'Clothing',    icon: '◈' },
  { id: 'bags',     fa: 'کیف',      en: 'Bags',         icon: '◉' },
  { id: 'shoes',    fa: 'کفش',      en: 'Shoes',        icon: '◆' },
  { id: 'acc',      fa: 'اکسسوری', en: 'Accessories',  icon: '◇' },
]

export const PALETTE_COLORS = {
  'مشکی':    '#111111',
  'سفید':    '#F5F5F5',
  'کرم':     '#EDE0C4',
  'طلایی':   '#C9A84C',
  'شراباتی': '#6B2035',
  'قهوه‌ای': '#5C3317',
  'خاکی':    '#8B7355',
  'نقره‌ای': '#B8B8B8',
  'صورتی':   '#DBA4B0',
  'آبی نفتی':'#1F4E5F',
  'سبز':     '#3D6B4F',
  'بنفش':    '#4A2C6B',
}

export const ORDER_STATUS = {
  new:       { fa: 'جدید',              color: '#2A72B8' },
  process:   { fa: 'در حال آماده‌سازی', color: '#B87A2A' },
  shipped:   { fa: 'ارسال شده',         color: '#6B3DAA' },
  done:      { fa: 'تحویل شده',         color: '#2A7A4E' },
  cancelled: { fa: 'لغو شده',           color: '#B82A2A' },
}

export const SHIP_OPTS = [
  { id: 'express',  label: 'ارسال فوری (۱ روز کاری)',       cost: 180000 },
  { id: 'standard', label: 'ارسال عادی (۳-۵ روز کاری)',    cost: 90000  },
  { id: 'free',     label: 'ارسال رایگان (۷-۱۰ روز کاری)', cost: 0      },
]

export const DEFAULT_SETTINGS = {
  heroTitle: 'کالکشن بهار ۱۴۰۴',
  heroEn:    'Spring — Summer Collection',
  heroCopy:  'ظریف‌ترین طرح‌های فصل، برای زنان معاصر',
  ticker:    'ارسال رایگان بالای ۱,۰۰۰,۰۰۰ تومان  ·  کد تخفیف LADY20  ·  بازگشت ۷ روزه',
}

/** @type {import('../services/database').Product[]} */
export const SEED_PRODUCTS = [
  {
    id: 'seed1',
    name: 'پیراهن ابریشم رُزا', nameEn: 'Rosa Silk Dress',
    category: 'clothing', code: 'LL-C001',
    price: 3800000, discount: 20,
    material: 'ابریشم ۱۰۰٪ ایتالیایی',
    description: 'پیراهن مجلسی با بافت ابریشمی اصل. یقه قایقی و دامن A‌شکل. مناسب مجالس رسمی.',
    colors: ['مشکی', 'کرم', 'شراباتی'],
    sizes:  ['XS', 'S', 'M', 'L', 'XL'],
    inventory: { 'XS-مشکی': 3, 'S-مشکی': 5, 'M-مشکی': 4, 'L-مشکی': 2, 'S-کرم': 4, 'M-کرم': 6, 'M-شراباتی': 3 },
    images: [], isNew: true, isBestseller: false, createdAt: Date.now() - 5000,
  },
  {
    id: 'seed2',
    name: 'کیف چرم کلاسیک آنا', nameEn: 'Ana Classic Leather Bag',
    category: 'bags', code: 'LL-B001',
    price: 6200000, discount: 0,
    material: 'چرم گاوی طبیعی ایتالیا',
    description: 'کیف دستی با چرم طبیعی گاوی. آستر پارچه، جیب‌های متعدد، بند شانه قابل تنظیم.',
    colors: ['مشکی', 'قهوه‌ای', 'کرم'], sizes: [],
    inventory: { 'مشکی': 8, 'قهوه‌ای': 5, 'کرم': 3 },
    images: [], isNew: false, isBestseller: true, createdAt: Date.now() - 10000,
  },
  {
    id: 'seed3',
    name: 'کفش پاشنه بلند لاکچری', nameEn: 'Luxury Stiletto',
    category: 'shoes', code: 'LL-S001',
    price: 4500000, discount: 15,
    material: 'چرم اصل ایتالیایی دست‌دوز',
    description: 'کفش پاشنه ۱۰ سانتی با چرم اصل. کاملاً دست‌دوز به تکنیک Goodyear Welt.',
    colors: ['مشکی', 'طلایی', 'کرم'],
    sizes:  ['36', '37', '38', '39', '40', '41'],
    inventory: { '36-مشکی': 2, '37-مشکی': 4, '38-مشکی': 5, '38-طلایی': 3, '39-کرم': 4 },
    images: [], isNew: false, isBestseller: true, createdAt: Date.now() - 15000,
  },
  {
    id: 'seed4',
    name: 'بلوز لینن مدرن', nameEn: 'Modern Linen Blouse',
    category: 'clothing', code: 'LL-C002',
    price: 1950000, discount: 0,
    material: 'لینن اروپایی ۱۰۰٪',
    description: 'بلوز یقه هفتی با لینن درجه یک. سبک، نفس‌پذیر، مناسب روزمره.',
    colors: ['کرم', 'سفید', 'خاکی'],
    sizes:  ['XS', 'S', 'M', 'L'],
    inventory: { 'S-کرم': 6, 'M-کرم': 5, 'S-سفید': 5, 'M-خاکی': 4 },
    images: [], isNew: true, isBestseller: false, createdAt: Date.now() - 20000,
  },
]
